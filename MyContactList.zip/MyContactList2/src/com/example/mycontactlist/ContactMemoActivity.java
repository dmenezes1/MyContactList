package com.example.mycontactlist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ContactMemoActivity extends Activity {
	private Contact currentContact;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contact_memo);
		Bundle extras = getIntent().getExtras();
		initTextChangedEvents();
		if (extras != null) {
			initContact(extras.getInt("contactid"));
		}
		initSaveButton();
		initBackButton();
		/*
		 * else { currentContact = new Contact(); }
		 */
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.contact_memo, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private void initContact(int id) {
		ContactDataSource ds = new ContactDataSource(ContactMemoActivity.this);
		ds.open();
		currentContact = ds.getSpecificContact(id);
		ds.close();
		EditText cname = (EditText) findViewById(R.id.editName1);
		EditText memoContent = (EditText) findViewById(R.id.editmemo);
		cname.setText(currentContact.getContactName());
		memoContent.setText(currentContact.getMemoContent());
	}

	private void initTextChangedEvents() {
		final EditText memoContent = (EditText) findViewById(R.id.editmemo);
		memoContent.addTextChangedListener(new TextWatcher() {
			public void afterTextChanged(Editable s) {
				currentContact.setMemoContent(memoContent.getText().toString());
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
				// TODO Auto-generated method stub

			}

			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				// TODO Auto-generated method stub
			}
		});

	}

	private void initSaveButton() {
		Button saveButton = (Button) findViewById(R.id.Save1);
		saveButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// hideKeyboard();
				ContactDataSource ds = new ContactDataSource(ContactMemoActivity.this);
				ds.open();
				boolean wasSuccessful = false;
				wasSuccessful = ds.updateContact(currentContact);
				ds.close();

			}
		});
	}
	private void initBackButton() {
		Button memoButton = (Button) findViewById(R.id.Back1);
		memoButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(ContactMemoActivity.this, ContactActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.putExtra( "contactid" ,currentContact.getContactID());
				startActivity(intent);
			}
		});
	}
}
