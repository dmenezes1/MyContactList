package com.example.mycontactlist;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.SupportMapFragment;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;


public class ContactMapActivity extends FragmentActivity {
	GoogleMap googleMap;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_contact_map);
		
		initLocationButton();
		initMapTypeButton();
		ImageButton list = (ImageButton) findViewById(R.id.imageButtonMap);
		list.setClickable(false);
		
		initListButton();
		//initMapButton();
		initSettingButton();
		
		final Geocoder geo = new Geocoder(this);
		FragmentManager fragManager = getSupportFragmentManager();
        SupportMapFragment supportMapFragment = (SupportMapFragment) fragManager.findFragmentById(R.id.map);
        supportMapFragment.getMapAsync(new OnMapReadyCallback() {
			@Override
	        public void onMapReady(final GoogleMap gMap) {
				ContactMapActivity.this.googleMap = gMap;
		        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
	
	        
				ArrayList<Contact> contacts = new ArrayList<Contact>();
				Contact currentContact = null;
				Bundle extras = getIntent().getExtras();
				if (extras != null ){
					ContactDataSource ds = new ContactDataSource(ContactMapActivity.this);
					ds.open();
					currentContact = ds.getSpecificContact(extras.getInt("contactid"));
					ds.close();
				}
				else {
					ContactDataSource ds = new ContactDataSource(ContactMapActivity.this);
					ds.open();
					contacts = ds.getContacts("contactname","ASC");
					ds.close();
				}
				
		        int measuredWidth = 0;  
		        int measuredHeight = 0;  
		        Point size = new Point();
		        WindowManager w = getWindowManager();
		
		        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB){
		            w.getDefaultDisplay().getSize(size);
		            measuredWidth = size.x;
		            measuredHeight = size.y; 
		        }else {
		            Display d = w.getDefaultDisplay(); 
		            measuredWidth = d.getWidth(); 
		            measuredHeight = d.getHeight()-180; 
		        }
		
		        if (contacts.size()>0) {
		            LatLngBounds.Builder builder = new LatLngBounds.Builder();
		            for (int i=0; i<contacts.size(); i++) {
		                currentContact = contacts.get(i);
		                        
		                //Geocoder geo = new Geocoder(this);
		                List<Address> addresses = null;
		                        
		                String address = currentContact.getStreetAddress() + ", " +
		                                    currentContact.getCity() + ", " +
		                                    currentContact.getState() + " " + 
		                                    currentContact.getZipCode();
		            
		                try {
		                    addresses = geo.getFromLocationName(address, 1);
		                } 
		                catch (IOException e) {
		                    e.printStackTrace();
		                }
		                LatLng point = new LatLng(addresses.get(0).getLatitude(),addresses.get(0).getLongitude());
		                builder.include(point);
		            
		                googleMap.addMarker(new MarkerOptions().position(point).title(currentContact.getContactName()).snippet(address));
		            }
		            googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(),measuredWidth, measuredHeight, 100));
		        }
		        else {
		            if (currentContact != null) {
		                //Geocoder geo = new Geocoder(this);
		                List<Address> addresses = null;
		                        
		                String address = currentContact.getStreetAddress() + ", " +
		                                    currentContact.getCity() + ", " +
		                                    currentContact.getState() + " " + 
		                                    currentContact.getZipCode();
		            
		                try {
		                    addresses = geo.getFromLocationName(address, 1);
		                } 
		                catch (IOException e) {
		                    e.printStackTrace();
		                }
		                LatLng point = new LatLng(addresses.get(0).getLatitude(),addresses.get(0).getLongitude());
		            
		                googleMap.addMarker(new MarkerOptions().position(point).title(currentContact.getContactName()).snippet(address));
		                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(point, 16));
		            }    
		            else {
		                AlertDialog alertDialog = new AlertDialog.Builder(ContactMapActivity.this).create();
		                alertDialog.setTitle("No Data");
		                alertDialog.setMessage("No data is available for the mapping function.");
		                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
			                public void onClick(DialogInterface dialog, int which) {
			                    finish();
			                } 
			            });
		                alertDialog.show();
		            }
		        }
			}
        });
	}
	
	private void initLocationButton() {
        final Button locationbtn = (Button) findViewById(R.id.buttonShowMe);
        locationbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String currentSetting = locationbtn.getText().toString();
                if (currentSetting.equalsIgnoreCase("Location On")) {
                    locationbtn.setText("Location Off");
                    googleMap.setMyLocationEnabled(true);
                }
                else {
                    locationbtn.setText("Location On");
                    googleMap.setMyLocationEnabled(false);
                }   
             }
        }); 
    }
	
	private void initMapTypeButton() {
        final Button satelitebtn = (Button) findViewById(R.id.buttonMapType);
        satelitebtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String currentSetting = satelitebtn.getText().toString();
                if (currentSetting.equalsIgnoreCase("Satellite View")) {
                    googleMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                    satelitebtn.setText("Normal View");
                }
                else {
                    googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                    satelitebtn.setText("Satellite View");
                }
            }
        }); 
    }  


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.contact_map, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	private void initListButton() {
		ImageButton list = (ImageButton) findViewById(R.id.imageButtonList);
		list.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(ContactMapActivity.this, ContactListActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
	}

	private void initMapButton() {
		ImageButton list = (ImageButton) findViewById(R.id.imageButtonMap);
		list.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(ContactMapActivity.this, ContactActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
	}

	private void initSettingButton() {
		ImageButton list = (ImageButton) findViewById(R.id.imageButtonSettings);
		list.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(ContactMapActivity.this, ContactSettingsActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(intent);
			}
		});
	}
}
